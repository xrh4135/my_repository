package com.cucumber.steps;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.io.File;
import java.io.IOException;
import java.util.List;

public class EnterPriseForm {

    static WebDriver driver;
    static WebDriverWait wait;
    static {
        System.setProperty("webdriver.chrome.driver", "src/test/resources/chromedriver.exe");

    }
    @Given("启动chrome浏览器")
    public void Prepare() {
        driver = new ChromeDriver();
        driver.manage().window().maximize();
        wait = new WebDriverWait(driver, 10);

    }
    @When("进入企业复工网站首页")
    public void Visit() throws InterruptedException {
        driver.get("https://templates.jinshuju.net/detail/Dv9JPD");
        wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("//iframe[@title='template-preview']"))));
        WebElement frame = driver.findElement(By.xpath("//iframe[@title='template-preview']"));
        driver.switchTo().frame(frame);
        Thread.sleep(1000);





    }
    @Then("勾选_连续生产_开工类企事业单位_截图并点击下一页")
    public void ActionsOfPageOne() throws InterruptedException {
        wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("//*[@id=\"root\"]/div/form"))));
        //将鼠标中轴滚动到最底部
        ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,document.body.scrollHeight)");
        List<WebElement> radios = driver.findElements(By.xpath("//div[@class='Radio_radio__AMdMG']"));
        for (WebElement radio : radios) {
            wait.until(ExpectedConditions.visibilityOf(radio.findElement(By.xpath("./label/span[2]/span[1]"))));
            String option = radio.findElement(By.xpath("./label/span[2]/span[1]")).getText();
            if (option.contains("连续生产")) {
                radio.findElement(By.xpath("./label/span[1]/input")).click();
            }
        }
        Thread.sleep(1000);
        //调用截图方法
        ScreenShot("pageone");
        //调用下一页方法
        NextPage();
    }
    @Then("填写第二页相关信息，截图并点击下一页")
    public void ActionsOfPageTwo() throws InterruptedException {
        wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("//form"))));
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[@class='ant-input-affix-wrapper picker-pc-input']/input")));
        //将鼠标中轴滚动到最底部
        ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,document.body.scrollHeight)");
        List<WebElement> inputs = driver.findElements(By.xpath("//input[@class='ant-input']"));
        inputs.get(0).click();
        wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("//a[@class='ant-picker-today-btn']"))));
        driver.findElement(By.xpath("//a[@class='ant-picker-today-btn']")).click();
        inputs.get(1).sendKeys("自动化");
        inputs.get(2).sendKeys("13888888888");
        Thread.sleep(1000);
        //调用截图方法
        ScreenShot("pagetwo");
        //调用下一页方法
        NextPage();
    }

    @Then("填写第三页相关信息，截图并提交")
    public void ActionsOfPageThree() throws InterruptedException {
        System.out.println("hahahhahahhahah");
        wait.until(ExpectedConditions.presenceOfAllElementsLocatedBy(By.xpath("//input[@class='ant-input-number-input']")));
        List<WebElement> numbers = driver.findElements(By.xpath("//input[@class='ant-input-number-input']"));
        System.out.println(numbers.size()+"*************************");
        List<WebElement> others = driver.findElements(By.xpath("//input[@class='ant-input']"));
        numbers.get(0).sendKeys("99");
        numbers.get(1).sendKeys("0");
        others.get(0).sendKeys("测试公司");
        others.get(1).click();
        wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("//a[@class='ant-picker-today-btn']"))));
        driver.findElement(By.xpath("//a[@class='ant-picker-today-btn']")).click();
        others.get(2).sendKeys("您的姓名");
        others.get(3).sendKeys("13888888888");
        //将鼠标中轴滚动到最底部
        ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,document.body.scrollHeight)");
        Thread.sleep(3000);
        ScreenShot("pagethree");
        NextPage();
    }

    @Then("判断是否成功，对结果进行截图")
    public void FinalActions() {
        wait.until(new ExpectedCondition<Boolean>() {
            public Boolean apply(WebDriver driver) {
                return driver.findElement(By.xpath("//div[@class='message']")).getText().equals("提交成功");
            }
        });
        ScreenShot("pagefour");
        driver.quit();
    }

    public void ScreenShot(String page) {
        File srcfile=((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
        try{
            FileUtils.copyFile(srcfile,new File("src/test/shots/"+page+".jpg"));

        }catch(IOException e) {
            e.printStackTrace();
        }
    }
    public void NextPage() {
        //wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("//div[@class='published-form__footer-buttons']/button"))));
        List<WebElement> buttons = driver.findElements(By.xpath("//div[@class='published-form__footer-buttons']/button"));
        for (WebElement button : buttons) {
            String name = button.findElement(By.xpath("./span")).getText();
            if (name.equals("下一页")||name.equals("提 交")) {
                button.click();
                break;
            }
        }
    }
}
