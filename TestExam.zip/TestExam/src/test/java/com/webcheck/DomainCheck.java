package com.webcheck;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import java.awt.*;
import java.util.List;

public class DomainCheck {
    static WebDriver driver;

    @DataProvider(name = "Data")
    public Object[][] data() {
        Object[][] datas = {{"您的姓名","Chrome"}, {"您的姓名", "IE"}, {"Selenium", "Chrome"}, {"Selenium", "IE"}};
        return datas;
    }

    @Test(dataProvider = "Data")
    public void Echo(String searchdata, String Browser) throws InterruptedException, AWTException {
        if (Browser.equals("Chrome")) {
            System.setProperty("webdriver.chrome.driver", "src/test/resources/chromedriver.exe");
            driver = new ChromeDriver();
        } else {
            System.setProperty("webdriver.ie.driver", "src/test/resources/IEDriverServer.exe");
            driver = new InternetExplorerDriver();
        }
        driver.manage().window().maximize();
        String url = "https://www.ianzhang.cn/bing/";
        driver.get(url);
        //设置等待并执行后续操作
        WebDriverWait wait = new WebDriverWait(driver, 10);
        driver.switchTo().alert().accept();
        driver.switchTo().frame("bing");
        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("sb_form_q")));
        WebElement input = driver.findElement(By.id("sb_form_q"));
        input.sendKeys(searchdata);
        //点击搜索按钮
        driver.findElement(By.id("search_icon")).click();
        //等待搜索结果页面加载完毕
        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("b_results")));
        //将鼠标中轴滚动到最底部
        ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,document.body.scrollHeight)");
        //定位向右点击箭头并点击(跳转到第二页)
        WebElement arrow = driver.findElement(By.xpath("//a[@title='下一页']"));
        JavascriptExecutor executor = (JavascriptExecutor) driver;
        executor.executeScript("arguments[0].click()", arrow);
        //翻页后等待页面加载
        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("b_results")));
        //遍历第二页的每一条的src信息
        int bing = 0;
        int baidu = 0;
        List<WebElement> cite_list = driver.findElements(By.xpath("//cite"));
        for (WebElement cite : cite_list) {
                String domain = cite.getText();
                System.out.println(domain);
                if (domain.contains("bing.com")) {
                    bing++;
                } else if (domain.contains("baidu.com")) {
                    baidu++;
                }
        }
        System.out.println("顶层域名为" + "baidu" + "的数量为:" + baidu);
        System.out.println("顶层域名为" + "bing" + "的数量为:" + bing);
        Thread.sleep(3000);
    }

    @AfterMethod
    public void Clear() {
        driver.quit();
    }

    @BeforeMethod
    public void SetUp() {

    }


}
